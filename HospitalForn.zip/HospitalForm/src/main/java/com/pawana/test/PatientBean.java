package com.pawana.test;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="hospital")
public class PatientBean {
	
	
	@Id
	
	@Column(name="id")
	private Integer patientId;
	@Column(name="fname")
	private String patientfname;
	@Column(name="lname")
	private String patientlname;
	@Column(name="padd")
	private String patientAdd;
	@Column(name="pmbno")
	private Integer patientMbno;
	
	public PatientBean() {
		super();
		
	}

	public PatientBean(Integer patientId, String patientfname, String patientlname, String patientAdd,
			Integer patientMbno) {
		super();
		this.patientId = patientId;
		this.patientfname = patientfname;
		this.patientlname = patientlname;
		this.patientAdd = patientAdd;
		this.patientMbno = patientMbno;
	}

	
	public Integer getPatientId() {
		return patientId;
	}

	
	public void setPatientId(Integer patientId) {
		this.patientId = patientId;
	}

	
	public String getPatientfname() {
		return patientfname;
	}

	
	public void setPatientfname(String patientfname) {
		this.patientfname = patientfname;
	}

	
	public String getPatientlname() {
		return patientlname;
	}

	
	public void setPatientlname(String patientlname) {
		this.patientlname = patientlname;
	}

	
	public String getPatientAdd() {
		return patientAdd;
	}

	
	public void setPatientAdd(String patientAdd) {
		this.patientAdd = patientAdd;
	}

	
	public Integer getPatientMbno() {
		return patientMbno;
	}

	public void setPatientMbno(Integer patientMbno) {
		this.patientMbno = patientMbno;
	}
	

	
}
